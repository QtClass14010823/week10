#include <QApplication>

#include "MainWin.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWin mainWin;

    mainWin.show();
    return a.exec();
}
