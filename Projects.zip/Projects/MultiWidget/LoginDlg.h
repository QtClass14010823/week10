#ifndef LOGINDLG_H
#define LOGINDLG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPushButton>


class LoginDlg : public QDialog
{
    Q_OBJECT
public:
    struct DialogValues
    {
        QString user;
        QString pass;
    };

    explicit LoginDlg(QWidget *parent = nullptr);
    DialogValues getDialogValues();

signals:

private slots:
    void onLoginButtonClicked();

private:
    QVBoxLayout *vLayout;
    QLineEdit *lnEditUser;
    QLineEdit *lnEditPass;
    QPushButton *btnLogin;
};

#endif // LOGINDLG_H
