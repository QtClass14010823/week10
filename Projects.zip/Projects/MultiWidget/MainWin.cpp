#include "MainWin.h"

#include <QDebug>
#include <QMessageBox>

#include "LoginDlg.h"

MainWin::MainWin(QWidget *parent) :
    QWidget(parent),
    loginDlg(this)
{
    loginBtn = new QPushButton("Show Login Dialog", this);

    qDebug() << connect(loginBtn, &QPushButton::clicked, this, &MainWin::onLoginButtonClicked);
}

void MainWin::onLoginButtonClicked()
{
    int res = loginDlg.exec();
    LoginDlg::DialogValues dlgValues;

    if (res == QDialog::Accepted)
    {
        dlgValues = loginDlg.getDialogValues();
        QMessageBox::information(this, "information",
                                 QString("%0 %1")
                                 .arg(dlgValues.user)
                                 .arg(dlgValues.pass));
    }
    else
    {
        QMessageBox::warning(this, "warning", "Login was not done.");
    }
}
