#ifndef COMMON_H
#define COMMON_H

#include <QSemaphore>

extern const int DataSize;

extern const int BufferSize;
extern char buffer[];

extern QSemaphore freeBytes;
extern QSemaphore usedBytes;

#endif // COMMON_H
