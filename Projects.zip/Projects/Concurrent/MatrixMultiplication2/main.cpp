#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QFuture>
#include <QtConcurrent>

#include <iostream>

uint vec_size;

struct MapElement {
    const QVector<double> *m_vec;
    MapElement(const QVector<double> *vec): m_vec(vec) {}
    typedef QPair<uint, double> result_type;

    QPair<uint, double> operator()(const QString& element)
    {
        QStringList splitElement = element.split(",");
        uint i = splitElement.at(0).toUInt();
        uint j = splitElement.at(1).toUInt();
        double aij = splitElement.at(2).toDouble();
        return qMakePair(i, aij*m_vec->at(j));
    }
};

bool populateMatrix(QString fileName, QStringList& sparseMatrix) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        qDebug("Matrix file could not be opened.");
        return false;
    }
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList splitLine = line.split(",");
        if(splitLine.size() != 3){
            qDebug() << "Invalid matrix format.";
            return false;
        }
        bool iOk = false;
        bool jOk = false;
        bool aijOk = false;
        splitLine.at(0).toUInt(&iOk);
        splitLine.at(1).toUInt(&jOk);
        splitLine.at(2).toDouble(&aijOk);
        if(iOk && jOk && aijOk){
            sparseMatrix.append(line);
        }
        else {
            qDebug() << "Invalid matrix element.";
            return false;
        }
    }
    return true;
}

bool populateVector(QString fileName, QVector<double>& vector){
    QFile file(fileName);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        qDebug() << "Vector file could not be opened.";
        return false;
    }
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        bool valueOk = false;
        double row = line.toDouble(&valueOk);
        if(valueOk)
            vector.append(row);
        else {
            qDebug() << "Invalid vector element.";
            return false;
        }
    }
    return true;
}

void reduce(QVector<double> &product,
                              const QPair<uint,double> &pair) {
    if(product.isEmpty())
        product.resize(vec_size);
    product[pair.first] += pair.second;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    QStringList sparseMatrix;
    bool matrixOk = populateMatrix("sparsematrix.txt", sparseMatrix);
    QVector<double> vec;
    bool vectorOk = populateVector("vector.txt", vec);

    if(matrixOk && vectorOk){
        vec_size = vec.size();
        QFuture<QVector<double>> f1;
        f1 = QtConcurrent::mappedReduced(sparseMatrix, MapElement(&vec),
                                     reduce);
        f1.waitForFinished();
        qDebug() << f1.result();
    }

    return 0;
    //return a.exec();
}
