#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void onSrcClicked();
    void onDstClicked();
    void onBckUpClicked();

private:
    void BackUp(QString src,QString des);
    QGridLayout *bLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcDir, *btnDstDir;
    QPushButton *btnBckUp;
};

#endif // FORM_H
