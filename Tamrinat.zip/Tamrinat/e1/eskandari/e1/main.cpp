#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

QLineEdit *pValue1LE = nullptr;
QLineEdit *pValue2LE = nullptr;

void onSwapPBclicked()
{
    QString temp;
    temp = pValue2LE->text();
    pValue2LE->setText(pValue1LE->text());
    pValue1LE->setText(temp);
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWidget myWidget;

    QLabel value1L("Value 1 :", &myWidget);
    value1L.move(10, 10);
    QLabel value2L("Value 2 :", &myWidget);
    value2L.move(10, 50);

    QLineEdit value1LE(&myWidget);
    value1LE.move(80, 10);
    QLineEdit value2LE(&myWidget);
    value2LE.move(80, 50);
    pValue1LE = &value1LE;
    pValue2LE = &value2LE;

    QPushButton exitPB("Exit", &myWidget);
    //exitPB.move(140, 100);
    exitPB.setGeometry(150, 100, 70, 50);
    QPushButton swapPB("Swap \n Values", &myWidget);
    //swapPB.move(30, 100);
    swapPB.setGeometry(60, 100, 70, 50);

    myWidget.show();

    QObject::connect(&exitPB, &QPushButton::clicked, &app, &QApplication::quit);
    QObject::connect(&swapPB, &QPushButton::clicked, onSwapPBclicked);

    return app.exec();
}
