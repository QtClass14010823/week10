#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QLayout>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QFile>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();
     int fileWordCounter(QString );
signals:

private slots:
    void onLineEnterPressed();


private:
    QGridLayout *fLayout;

    QLabel *lblFname,*lblInfo;
    QLineEdit *lnEditName;
    QPushButton *btnQuit;
    QFile fp;
};



#endif // FORM_H
