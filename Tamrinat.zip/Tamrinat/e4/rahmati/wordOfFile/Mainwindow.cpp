#include "Mainwindow.h"

#include <QFile>
#include <QMessageBox>
#include <QProcess>
#include <QScreen>
#include <QRegularExpression>
#include <QRegularExpressionValidator>

QString strWordCount="Word Count: ";

int MainWindow::get_total_word(QString fileName)
{
    QString strRe="";
#ifdef Q_OS_LINUX
    strRe="^(/[^/ ]*)+/?$";
    strRe="^(.+)\\/([^\\/]+)$";
#elif defined(Q_OS_WINDOWS)
    strRe+="^";
    strRe+="(?<drive>[a-z]:)?";
    strRe+="(?<path>(?:[\\]?(?:[\\w !#()-]+|[.]{1,2})+)*[\\])?";
    strRe+="(?<filename>(?:[.]?[\\w !#()-]+)+)?[.]?";
    strRe+="$";
#endif
    QRegularExpression re(strRe);
    QRegularExpressionValidator v(re, 0);
    QString strTmp=fileName;
    int pos=0;
    bool res=v.validate(strTmp,pos);
    if(!res)
    {
        QMessageBox msgBox;
        msgBox.critical(nullptr,"Error","File path not vallid !!!\n"+strTmp,QMessageBox::Ok);
        return -1;
    }

    QFile file(fileName);
    if(!file.exists())
    {
        QMessageBox msgBox;
        msgBox.critical(nullptr,"Error","File not exists !!!\n"+fileName,QMessageBox::Ok);
        return -1;
    }
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);
    int numberOfWord=0;
    while (!in.atEnd())
    {
        in.readLineInto(&strTmp,300);
        strTmp=strTmp.simplified();
        if(strTmp.length()<1)   continue;//to avoid empty string
        QStringList sl= strTmp.split(" ");
        numberOfWord+=sl.count();
    }
    file.close();
    return numberOfWord;
}
void MainWindow::leReturnPressed()
{
    int res=get_total_word(leFp->text());
    lblWc->setText(strWordCount+QString::number(res));

}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)

{
    this->setMinimumSize(300,150);
    move(screen()->geometry().center() - frameGeometry().center());
    setWindowTitle("Word Count");
    setCentralWidget(window);

    gl->addWidget(lblFp,0,0,1,1);
    gl->addWidget(leFp,0,1,1,1);
    gl->addWidget(lblWc,1,0,1,1);
    gl->addWidget(btnQuit,2,0,1,2);

    window->setLayout(gl);

    lblFp->setText("File Path: ");
    lblWc->setText(strWordCount);
    btnQuit->setText("Quit");

    leFp->setText("/home/user1/t.txt");

    connect(btnQuit,&QPushButton::clicked,this,&MainWindow::close);
    btnQuit->setAutoDefault(true);//will automatically be pressed when the user presses enter
    connect(leFp,&QLineEdit::returnPressed,this,&MainWindow::leReturnPressed);
}

MainWindow::~MainWindow()
{

}

