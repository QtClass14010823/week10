#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QGroupBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void leReturnPressed();
    static int get_total_word(QString fileName);

private:
    Ui::MainWindow *ui;
    QWidget *window=new QWidget(this);
    QGridLayout *gl=new QGridLayout(window);
    QLabel      *lblFp=new QLabel(window);
    QLineEdit   *leFp=new QLineEdit(window);
    QLabel      *lblWc=new QLabel(window);
    QPushButton *btnQuit=new QPushButton(window);

};



#endif // MAINWINDOW_H
