#ifndef MY_FILE_H
#define MY_FILE_H

#include <QWidget>
#include<QPushButton>
#include<QLineEdit>
#include<QLabel>
#include<QGroupBox>
#include<QGridLayout>
#include<QRegularExpression>
#include<QRegularExpressionValidator>
#include<QMessageBox>
#include<QtGlobal>
#include<QFile>
class My_File : public QWidget
{
    Q_OBJECT

public:
    My_File(QWidget *parent = nullptr);
    ~My_File();
    int File_Analyse(QString Fname);
private slots:
    void My_Slot();

private:
    QGroupBox *gbox();
    QLabel  *Pathlbl;
    QLabel  *FileInfoLbl;
    QLabel  *WordCtrLbl;
    QLineEdit *PathLnedit;
    QPushButton *QuitBtn;
    QGridLayout  *MainGrid;
    QWidget *MainWidget;

#if defined (Q_OS_LINUX)
    QString PATTERN = "^(/[^/]*)+.(txt|dat)/?$"; //LINUX_PATTERN
#elif defined (Q_OS_WIN)
    QString PATTERN = "([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+.(txt|dat)\\\\?";//WIN_PATTERN
#endif

};
#endif // MY_FILE_H
