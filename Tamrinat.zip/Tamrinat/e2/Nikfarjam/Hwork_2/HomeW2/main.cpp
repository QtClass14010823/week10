#include "mainwindow.h"
#include <QApplication>
#include<QLineEdit>
#include<QLabel>
#include <QString>
#include<QPushButton>
#include<QObject>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);  
    MainWindow w;

    QLabel *labelArr = nullptr;
    QLineEdit *lnEdtArr= nullptr;
    QPushButton *btm=new QPushButton ("EXIT") ;

    lnEdtArr =new QLineEdit[argc];
    labelArr = new QLabel[argc];

    btm->setParent(&w);

    if(!lnEdtArr)
        return  1;

    if(!labelArr)
        return  1;

     for (int i = 1; i < argc; i++)
    {
        QString str1,str2,str3,str4;
        str1=argv[i];
        str2 ="Parameter ";
        str3=QString::number(i);
        str4= str2+str3;

        lnEdtArr[i].setParent(&w);
        labelArr[i].setParent(&w);

        lnEdtArr[i].setText(str1);
        labelArr[i].setText(str4);
        lnEdtArr[i].setReadOnly(true);
        labelArr[i].setGeometry(5,(i)*50,100,30);
        lnEdtArr[i].setGeometry(100,(i)*50,150,30);
    }
         btm->setGeometry(100,(argc+1)*50,150,30);
         QObject::connect(btm,SIGNAL(clicked(bool)),&w,SLOT(close()));
         w.setGeometry(100,100,300,400);

    w.show();
    return a.exec();
}
