#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QGroupBox>

struct ContactInfo{
    char cName[20];
    int iTel;
};

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void onAddClicked();
    void onFindClicked();
private:
    QVBoxLayout layout;
    QGridLayout layInfo,layAdd,layFind,layQuit;
    QGroupBox grBoxInfo,grBoxAdd,grBoxFind;
    QLabel lblCount,lblCnt,lblName,lblTel,lblfName;
    QLineEdit ledtName,ledtTel,ledtfName;
    QPushButton butAdd,butFind,butQuit;
};

#endif // FORM_H
